import React from 'react'
import './Game.css';

export default function Game() {
   return (
    <>
        <Circle />
        <Circle />
        <Circle />
        <Circle />
        <Circle />
    </>
   );
}

class Circle extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            xPos: this.getRandom(3, 53),  //starting x-coordinate
            yPos: this.getRandom(3, 40),  //starting y-coordinate
            direction: this.getRandom(0, 360),  //movement direction
            color: Object.keys(Color)[Math.floor(Math.random() * Object.keys(Color).length)],  //starting color
        }
    }

    getRandom(min, max) {
        min = Math.ceil(min);
        max = Math.floor(max);
        return Math.floor(Math.random() * (max - min) + min);
    }

    render() {
        document.documentElement.style.setProperty('--x1', `${this.state.xPos}px`);
        document.documentElement.style.setProperty('--y1', `${this.state.yPos}px`);
        document.documentElement.style.setProperty('--x2', `${Math.sqrt(Math.pow(2000, 2) + Math.pow(2000, 2)) * Math.cos(this.state.direction)}px`);
        document.documentElement.style.setProperty('--y2', `${Math.sqrt(Math.pow(2000, 2) + Math.pow(2000, 2)) * Math.sin(this.state.direction)}px`);
        return (
            <div >
                <svg className='circle' style={{
                    left: `calc(${this.state.xPos}vw - 60px)`, 
                    top: `calc(${this.state.yPos}vw - 60px)`,
                    }} 
                    >
                <circle cx={30} cy={30} r={30} fill={this.state.color}/>
            </svg>
            </div>
               
        );
    }
    
}

class Color {
    static Green = new Color('green');
    static Blue = new Color('blue');
    static Yellow = new Color('yellow');
    static Red = new Color('red');
    static Pink = new Color('pink');
    static Orange = new Color('orange');
  
    constructor(name) {
      this.name = name;
    }
    toString() {
      return `Color.${this.name}`;
    }
  }


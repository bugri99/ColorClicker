import './App.css';
import Game from './components/Game';

function App() {
  document.body.style.overflow = "hidden"
  return (
    <div className="App">
      <header className="App-header">
      <div className='App-game'>   
      <Game />   
        </div>
        <div className='App-upgrades'>      
        </div>
      </header>
    </div>
  );
}

export default App;
